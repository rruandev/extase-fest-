// api/webhook-pix.js
// Mercado Pago chama esta rota automaticamente quando o pagamento é confirmado
// Ela envia o email com o ingresso para o comprador

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { type, data } = req.body;

  // Só processa notificações de pagamento
  if (type !== 'payment') {
    return res.status(200).json({ ok: true });
  }

  try {
    // Busca os detalhes do pagamento no Mercado Pago
    const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${data.id}`, {
      headers: { 'Authorization': `Bearer ${process.env.MP_ACCESS_TOKEN}` }
    });
    const payment = await mpRes.json();

    // Só envia o ingresso se o pagamento foi aprovado
    if (payment.status !== 'approved') {
      return res.status(200).json({ ok: true, status: payment.status });
    }

    const { comprador_nome, comprador_email, lote, quantidade } = payment.metadata;
    const valor = payment.transaction_amount;
    const codigoIngresso = '#AC2026-' + payment.id.toString().slice(-5).padStart(5,'0');

    // Monta o HTML do email com o ingresso
    const emailHtml = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Seu ingresso — After do Chefe</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
  <div style="max-width:480px;margin:0 auto;padding:2rem 1rem">

    <div style="text-align:center;margin-bottom:1.5rem">
      <p style="font-size:28px;margin-bottom:.5rem">🇧🇷</p>
      <h1 style="font-size:22px;font-weight:700;color:#1a1a1a;margin:0">After do Chefe</h1>
      <p style="font-size:13px;color:#888;margin:.4rem 0 0">Seu ingresso está confirmado!</p>
    </div>

    <div style="background:#fff;border-radius:16px;padding:1.5rem;margin-bottom:1rem;border:1px solid #e8e8e4">
      <p style="font-size:13px;color:#888;margin:0 0 .5rem">Olá, <strong style="color:#1a1a1a">${comprador_nome}</strong>!</p>
      <p style="font-size:14px;color:#555;line-height:1.6">
        Seu pagamento foi confirmado. Abaixo está seu ingresso digital para o <strong>After do Chefe</strong>.
        Apresente o QR Code na entrada do evento.
      </p>
    </div>

    <!-- INGRESSO -->
    <div style="background:#0d0d1a;border-radius:16px;padding:1.5rem;color:#fff;margin-bottom:1rem">
      <p style="font-size:10px;color:rgba(255,255,255,0.4);text-transform:uppercase;letter-spacing:.08em;margin:0 0 4px">After do Chefe 🇧🇷</p>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
        <p style="font-size:22px;font-weight:700;margin:0">${lote}</p>
        <p style="font-size:20px;font-weight:700;margin:0">R$ ${valor.toFixed(2).replace('.', ',')}</p>
      </div>
      <hr style="border:none;border-top:1.5px dashed rgba(255,255,255,0.2);margin:0 0 1rem">
      <div style="display:flex;align-items:center;gap:1rem">
        <img
          src="https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(codigoIngresso + '|' + comprador_nome + '|After do Chefe|09/05/2026')}"
          width="80" height="80"
          style="border-radius:8px;border:none;display:block;background:#fff"
          alt="QR Code ingresso"
        >
        <div>
          <p style="font-size:14px;font-weight:600;margin:0 0 3px">${comprador_nome}</p>
          <p style="font-size:12px;color:rgba(255,255,255,0.55);margin:0">Sáb, 09 Mai 2026 • 21h00</p>
          <p style="font-size:12px;color:rgba(255,255,255,0.55);margin:2px 0">Brasília, DF</p>
          <p style="font-size:10px;color:rgba(255,255,255,0.3);font-family:monospace;margin:6px 0 0">${codigoIngresso}</p>
        </div>
      </div>
    </div>

    <div style="background:#fff;border-radius:12px;padding:1.25rem;border:1px solid #e8e8e4;margin-bottom:1rem">
      <p style="font-size:13px;font-weight:600;color:#333;margin:0 0 .75rem">Informações do evento</p>
      <table style="width:100%;font-size:13px;border-collapse:collapse">
        <tr><td style="color:#888;padding:4px 0">Data</td><td style="text-align:right;font-weight:500">Sábado, 09 de Maio de 2026</td></tr>
        <tr><td style="color:#888;padding:4px 0">Horário</td><td style="text-align:right;font-weight:500">21h00</td></tr>
        <tr><td style="color:#888;padding:4px 0">Local</td><td style="text-align:right;font-weight:500">Brasília, DF</td></tr>
        <tr><td style="color:#888;padding:4px 0">Código</td><td style="text-align:right;font-family:monospace;font-size:12px">${codigoIngresso}</td></tr>
      </table>
    </div>

    <p style="font-size:12px;color:#aaa;text-align:center;margin-top:1.5rem">
      Dúvidas? Responda este email.<br>
      <strong>Não transfira este ingresso</strong> — ele é nominal e vinculado ao seu CPF.
    </p>
  </div>
</body>
</html>
    `;

    // Envia o email via Resend (https://resend.com — gratuito até 3.000 emails/mês)
    const emailRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // API Key do Resend (variável de ambiente no Vercel)
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`
      },
      body: JSON.stringify({
        // SUBSTITUA pelo seu domínio verificado no Resend
        // (pode usar onboarding@resend.dev para testes)
        from: 'After do Chefe <ingressos@afterdochefe.com.br>',
        to: comprador_email,
        subject: `🎉 Seu ingresso confirmado — After do Chefe (${lote})`,
        html: emailHtml
      })
    });

    if (!emailRes.ok) {
      const emailError = await emailRes.json();
      console.error('Resend error:', emailError);
      // Não retorna erro — pagamento já foi confirmado
    }

    return res.status(200).json({ ok: true, ingresso: codigoIngresso });

  } catch (err) {
    console.error('Webhook error:', err);
    return res.status(500).json({ error: 'Erro interno' });
  }
}
